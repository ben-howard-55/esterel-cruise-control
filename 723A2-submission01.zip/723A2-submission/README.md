# Running this project

The main Esterel file is called: `produceConsume.strl`. This was due to the fact that when we where implementing the project with the makefile provided in Lab01, our strl would not compile if we renamed files. Similarly, the same is for the "cruise controller", the contents of the C file was placed inside of `produceConsume_data.c`.

In order to run this project:
- from the root of the project: `make produceConsume.xes`
- then run `./producesConsume.xes`
