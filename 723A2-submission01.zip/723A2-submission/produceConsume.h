float regulateThrottle(boolean isGoingOn, float cruiseSpeed, float vehicleSpeed);
